xrandr setprovideroutputsource modesetting NVIDIA-0
xrandr --auto
xrandr --dpi 96
